package hospitalproject;

public class Patient extends Person {

    private int age;
    private String gender;
    private String status;
    private Nurse nurse;

    public Patient() {
    }

    public Patient(String name, int id, String phone, int age, String gender, String status, Nurse nurse) {
        super(name, id, phone);
        this.age = age;
        this.gender = gender;
        this.status = status;
        this.nurse = nurse;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Nurse getNurse() {
        return nurse;
    }

    public void setNurse(Nurse nurse) {
        this.nurse = nurse;
    }

    @Override
    public String toString() {
        return " name: " + name + ", id: " + id
                + ", age: " + age
                + ", gender: " + gender
                + ", status: " + status + ", phone: " + phone
                + "\nNurse Details: " + nurse;

    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Patient other = (Patient) obj;
        return this.age == other.age;
    }

}
