package hospitalproject;

import java.io.FileWriter;
import java.io.IOException;

public class Reservation implements Hospital {

    private int id;
    private Patient patient;
    private Doctor doctor;
    private String date;
    private String time;
    private static int NumberObjects = 0;

    public Reservation() {
    }

    {
        NumberObjects++;
    }

    public Reservation(int id, Patient patient, Doctor doctor, String date, String time) {
        this.id = id;
        this.patient = patient;
        this.doctor = doctor;
        this.date = date;
        this.time = time;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    @Override
    public void saveReservation() throws IOException {
        int reID = patient.getId();
        FileWriter writer = new FileWriter(reID + ".txt", true);
        writer.write(this.toString());
        writer.close();
    }

    public static int getNumberObjects() {
        return NumberObjects;
    }

    
    @Override
    public String toString() {
        return "Hospital Name: " + NAME + "\nHospital Address: " + ADDRESS
                + "\nReservation ID: " + id
                + "\nPatient Details: " + patient + "\nDoctor Details: " + doctor + "\nDate: " + date + "\nTime: " + time;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Reservation other = (Reservation) obj;
        return this.id == other.id;
    }

}
