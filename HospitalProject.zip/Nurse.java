package hospitalproject;

import java.util.Objects;

public class Nurse extends Staff {

    private String shift;

    public Nurse() {
    }

    public Nurse(String name, int id, String phone, double salary, String shift) {
        super(name, id, phone, salary);
        this.shift = shift;
    }

    public String getShift() {
        return shift;
    }

    public void setShift(String shift) {
        this.shift = shift;
    }

    @Override
    public String toString() {
        return "name: " + name
                + ", id: " + id
                + ", shift: " + shift
                + ", salary: " + salary
                + ", phone: " + phone;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Nurse other = (Nurse) obj;
        return Objects.equals(this.shift, other.shift);
    }

}
