package hospitalproject;

import java.io.IOException;

public interface Hospital {

    public final String NAME = "Hospital";
    public final String ADDRESS = "123 Main St.";

    public void saveReservation() throws IOException;

}
