package hospitalproject;

public abstract class Staff extends Person {

    protected double salary;

    public Staff() {
    }

    public Staff(String name, int id, String phone, double salary) {
        super(name, id, phone);
        this.salary = salary;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    @Override
    public String toString() {
        return " name: " + name
                + ", id: " + id
                + ", phone: " + phone + " salary: " + salary;
    }
}
