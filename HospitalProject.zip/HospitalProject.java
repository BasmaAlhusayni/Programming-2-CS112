// this program is a hospital management system (it's my project for this course)
package hospitalproject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class HospitalProject {

    static ArrayList<Nurse> nurses = new ArrayList<>();
    static ArrayList<Operation> operations = new ArrayList<>();
    static ArrayList<Doctor> doctors = new ArrayList<>();

    public static void main(String[] args) throws IOException {
        int choice = 0;
        do {
            choice = menu();
            switch (choice) {
                case 1:
                    addReservation();
                    break;
                case 2:
                    viewReservations();
                    break;
                case 3:
                    deleteReservations();
                    break;
                case 4:
                    addOperation();
                    break;
                case 5:
                    addNurse();
                    break;
                case 6:
                    addDoctor();
                    break;
                case 7:
                    System.out.println("Thank you for using the Hospital Management System!");
                    break;
                default:
                    System.out.println("Invalid input! Please enter a number between 1 and 7.");
            }
        } while (choice != 7);
    }

    public static int menu() {
        Scanner input = new Scanner(System.in);
        System.out.println("Welcome to the Hospital Management System!");
        System.out.println("Please choose an option:");
        System.out.println("1. Add Reservations");
        System.out.println("2. View Reservations");
        System.out.println("3. Delete Reservations");
        System.out.println("4. Add Operation");
        System.out.println("5. Add Nurse");
        System.out.println("6. Add Doctor");
        System.out.println("7. Exit");
        System.out.print("Enter your choice: ");
        return input.nextInt();
    }

    public static void addDoctor() {
        Scanner input = new Scanner(System.in);
        System.out.println("Please enter the following doctor details:");

        System.out.print("Doctor Name: ");
        String name = input.nextLine();

        System.out.print("Doctor ID: ");
        int id = input.nextInt();

        System.out.print("Doctor Phone: ");
        String phone = input.nextLine();
        phone = input.nextLine();
        System.out.print("Doctor Salary: ");

        double salary = input.nextDouble();

        System.out.print("Doctor Specialization: ");
        String specialization = input.nextLine();
        specialization = input.nextLine();
        System.out.print("Doctor Degree: ");
        String degree = input.nextLine();
        while (operations.isEmpty()) {
            System.out.println("No operations available! Please add an operation first.");
            addOperation();
        }
        Doctor doctor = new Doctor(name, id, phone, salary, specialization, degree, operations);
        doctors.add(doctor);
        System.out.println("Doctor added successfully!");
        System.out.println("Doctor Details: " + doctor.toString());
        System.out.println("_________________________________________________________");

    }

    public static Doctor getDoctor() {
        Scanner input = new Scanner(System.in);
        System.out.println("Choose Doctor for the Reservation:");
        for (int i = 0; i < doctors.size(); i++) {
            System.out.println((i + 1) + ". " + doctors.get(i).getName());
        }
        System.out.print("Enter your choice: ");

        int choice = input.nextInt();
        while (choice < 1 || choice > doctors.size()) {
            System.out.println("Invalid input! Please enter a numeric choice value.");
            System.out.print("Enter your choice: ");
            choice = input.nextInt();
        }

        return doctors.get(choice - 1);
    }

    public static void addOperation() {
        Scanner input = new Scanner(System.in);
        System.out.println("Please enter the following operation details:");

        System.out.print("Operation Name: ");
        String name = input.nextLine();

        System.out.print("Operation Date (dd-mm-yyyy): ");
        String date = input.nextLine();

        System.out.print("Operation Time (24-hour format HH:mm): ");
        String time = input.nextLine();

        System.out.print("Operation Room Number: ");
        int room = input.nextInt();
        Operation operation = new Operation(name, date, time, room);
        System.out.println("Operation added successfully!");
        System.out.println("Operation Details: " + operation.toString());
        System.out.println("_________________________________________________________");
        operations.add(operation);

    }

    public static void addNurse() {
        Scanner input = new Scanner(System.in);
        System.out.println("Please enter the following nurse details:");
        System.out.print("Nurse Name: ");
        String name = input.nextLine();
        System.out.print("Nurse ID: ");
        int id = input.nextInt();

        System.out.print("Nurse Phone: ");
        String phone = input.nextLine();
        phone = input.nextLine();
        System.out.print("Nurse Salary: ");

        double salary = input.nextDouble();
        System.out.print("Nurse Shift: ");
        String shift = input.nextLine();
        shift = input.nextLine();
        Nurse nurse = new Nurse(name, id, phone, salary, shift);
        nurses.add(nurse);
        System.out.println("Nurse added successfully!");
        System.out.println("Nurse Details: " + nurse.toString());
        System.out.println("_________________________________________________________");
    }

    public static Patient addPatient() {
        Scanner input = new Scanner(System.in);
        System.out.println("Please enter the following patient details:");

        System.out.print("Patient Name: ");
        String name = input.nextLine();

        System.out.print("Patient ID: ");
        int id = input.nextInt();

        System.out.print("Patient Phone: ");
        String phone = input.nextLine();
        phone = input.nextLine();
        System.out.print("Patient Age: ");
        int age = input.nextInt();
        System.out.print("Patient Gender: ");
        String gender = input.nextLine();
        gender = input.nextLine();

        System.out.print("Patient Status: ");
        String status = input.nextLine();
        while (nurses.isEmpty()) {
            System.out.println("No nurses available! Please add a nurse first.");
            addNurse();
        }
        System.out.println("Choose Nurse for the Patient:");
        for (int i = 0; i < nurses.size(); i++) {
            System.out.println((i + 1) + ". " + nurses.get(i).getName());
        }
        int choice = -1;
        while (choice < 1 || choice > nurses.size()) {
            System.out.print("Enter your choice: ");
            while (!input.hasNextInt()) {
                System.out.println("Invalid input! Please enter a numeric choice value.");
                input.next();
            }
            choice = input.nextInt();
        }
        Nurse nurse = nurses.get(choice - 1);
        System.out.println("Patient added successfully!");
        Patient patient = new Patient(name, id, phone, age, gender, status, nurse);
        System.out.println("Patient Details: " + patient.toString());
        System.out.println("_________________________________________________________");
        return patient;
    }

    public static void addReservation() throws IOException {
        Scanner input = new Scanner(System.in);
        System.out.println("Please enter the following reservation details:");
        System.out.print("Reservation ID: ");
        int id = input.nextInt();
        System.out.print("Reservation Date (dd-mm-yyyy): ");
        String date = input.nextLine();
        date = input.nextLine();
        System.out.print("Reservation Time (24-hour format HH:mm): ");
        String time = input.nextLine();
        Patient patient = addPatient();
        Doctor doctor = getDoctor();
        while (doctor == null) {
            System.out.println("Doctor not found");
            addDoctor();
            doctor = getDoctor();
        }
        Reservation reservation = new Reservation(id, patient, doctor, date, time);
        reservation.saveReservation();
        System.out.println("Reservation added successfully!");
        System.out.println(reservation.toString());
        System.out.println("this is the number of reservations in total: " + Reservation.getNumberObjects());
    }

    private static void deleteReservations() {
        Scanner input = new Scanner(System.in);
        System.out.println("Please enter the following reservation details:");
        System.out.println("Please enter the patient ID: ");
        int id = input.nextInt();
        File file = new File(id + ".txt");
        if (!file.exists()) {
            System.out.println("Reservation not found");
        } else {
            file.delete();
            System.out.println("Reservation deleted successfully");
        }
    }

    private static void viewReservations() throws FileNotFoundException {
        Scanner input = new Scanner(System.in);
        System.out.println("Please enter the following reservation details:");
        System.out.println("Please enter the patient ID: ");
        String id = input.nextLine();
        File file = new File(id + ".txt");
        if (!file.exists()) {
            System.out.println("Reservation not found");
        } else {
            Scanner scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                System.out.println(scanner.nextLine());
            }
        }
    }
}
