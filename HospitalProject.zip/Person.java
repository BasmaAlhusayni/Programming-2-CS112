package hospitalproject;

public abstract class Person {

    protected String name;
    protected int id;
    protected String phone;

    public Person() {
    }

    public Person(String name, int id, String phone) {
        this.name = name;
        this.id = id;
        this.phone = phone;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Override
    public String toString() {
        return " name: " + name
                + ", id: " + id
                + ", phone: " + phone;
    }
}
