package hospitalproject;

import java.util.Objects;

public class Operation {

    private String name;
    private String date;
    private String time;
    private int room;

    public Operation() {
    }

    public Operation(String name, String date, String time, int room) {
        this.name = name;
        this.date = date;
        this.time = time;
        this.room = room;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getRoom() {
        return room;
    }

    public void setRoom(int room) {
        this.room = room;
    }

    @Override
    public String toString() {
        return "name: " + name
                + ", date: " + date
                + ", time: " + time
                + ", room: " + room;

    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Operation other = (Operation) obj;
        return Objects.equals(this.name, other.name);
    }

}
