package hospitalproject;

import java.util.ArrayList;
import java.util.Objects;

public class Doctor extends Staff {

    private String specialization;
    private String degree;

    private ArrayList<Operation> operations;

    public Doctor() {
    }

    public Doctor(String name, int id, String phone, double salary, String specialization, String degree, ArrayList<Operation> operations) {
        super(name, id, phone, salary);
        this.specialization = specialization;
        this.degree = degree;
        this.operations = operations;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public String getDegree() {
        return degree;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }

    public ArrayList<Operation> getOperations() {
        return operations;
    }

    public void setOperations(ArrayList<Operation> operations) {
        this.operations = operations;
    }

    @Override
    public String toString() {
        return "name: " + name + ", id: " + id + ", degree: " + degree + ", specialization: " + specialization + ", phone: " + phone + ", salary: " + salary;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Doctor other = (Doctor) obj;
        return Objects.equals(this.degree, other.degree);
    }

}
