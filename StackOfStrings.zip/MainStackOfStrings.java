//this program explains how "first in\last out" works in Java
package mainstackofstrings;

import java.util.Scanner;

public class MainStackOfStrings {

    public static void main(String[] args) {
        StackOfStrings stack = new StackOfStrings();
        System.out.println("STACK OF STRINGS\nType PSH followed by a space and a string\nType POP to let the last string pop out of the stack\nType PEK to display the string at the top of the stack\nType STP to stop the program");
        Scanner input = new Scanner(System.in);
        while (true) {
            System.out.print("Enter command: ");
            String s = input.nextLine();
            String stackCommand = s.substring(0, 3);
            switch (stackCommand) {
                case "PSH":
                    stack.push(s.substring(s.indexOf(" ") + 1));
                    stack.printStack();
                    break;
                case "POP":
                    System.out.println(stack.pop());
                    stack.printStack();
                    break;
                case "PEK":
                    System.out.println(stack.peek());
                    stack.printStack();
                    break;
                case "STP":
                    System.exit(0);
                default:
                    System.out.println("Illegal input. Try again.");
            }
        }
    }
}
