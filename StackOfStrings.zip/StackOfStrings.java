package mainstackofstrings;

public class StackOfStrings {

    private String[] elements;
    private int size;
    public static final int DEFAULT_CAPACITY = 4;

    public StackOfStrings() {
        this(DEFAULT_CAPACITY);
    }

    public StackOfStrings(int capacity) {
        elements = new String[capacity];
    }

    public boolean empty() {
        return size == 0;
    }

    public void push(String value) {
        if (size >= elements.length) {
            String[] temp = new String[elements.length * 2];
            System.arraycopy(elements, 0, temp, 0, elements.length);
            elements = temp;
        }

        elements[size++] = value;
    }

    public String pop() {
        if (empty()) {
            return "Stack is Empty";
        }
        String data = elements[--size];
        elements[size] = null;
        return data;
    }

    public String peek() {
        if (empty()) {
            return "Stack is Empty";
        }
        return elements[size - 1];
    }

    public void printStack() {
        System.out.print("Stack (top to bottom):\n");
        for (int i = size - 1; i > -1; i--) {
            System.out.println(elements[i] + " ");
        }
        System.out.println();
    }

}
